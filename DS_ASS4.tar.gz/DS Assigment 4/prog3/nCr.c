/*required header files*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*swap() for swaping element each other*/
void swap(char *t1,char *t2){
   char t;
   t = *t1;
   *t1 = *t2;
   *t2 = t;
}
/*find all permutation of string*/
void nCr(char *a,int l,int r){
  int i;
  if(l == r)
   printf("%s\n",a);
   else{
       for(i=l;i<=r;i++)
       {
         swap((a+l),(a+i));
         nCr(a,l+1,r);
         swap((a+l),(a+i));
       }
   }
}
/*driver code*/
int main(int argc, char const *argv[]) {
  /*variable declaration*/
  char *str;
  int n;
  /*user input*/
  printf("how many char of string :");
  scanf("%d",&n);
  /*allowcate memory to string*/
  str = (char*)malloc(sizeof(char)*n);
  printf("\nEnter the string :");
  scanf("%s",str);
  /*print all permutation of string*/
    printf("\npermutation of string :\n");
    nCr(str,0,strlen(str)-1);
  return 0;
}
