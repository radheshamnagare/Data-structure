/*required header files*/
using namespace std;
#include<iostream>
#include<stdexcept>
#include"hash_tbl.h"

/*defination of class*/
class find_prefix_string :public hash_tbl{
  
  /*declaration of variable*/
   private :
       string t;
       int sz;
   public :
     /*constructor of class for initilize instance member*/
     find_prefix_string(){
       sz = 0;
       t.clear();
       init(); 
     }
     /*get usre input*/
     void init(){
     	cout<<"\nEnter the prefix string (t) :";
     	cin>>t;    	
     }
     /*inser string using hash table*/
     void _insert_str(){
     	sz = _size();
     	for(int i=0;i<sz;i++){
     		_insert();
     	}
     }
     /*check prefix string in hash table value*/
     void check_prefix(){
        init_glob();
        sz = _size();
       
        for(int i=0;i<sz;i++){
        	string val = _get();
        	if(val.length()>0)
        	{   
        		if(val.length() >= t.length())
        		{
        			if(t == val.substr(0,t.length()))
        				cout<<val<<endl;
        		}
        	}
        	else
        		break;
        }
     }


};
/*driver code*/
int main(int argc, char const *argv[])
{
	find_prefix_string px;

	px._insert_str();
	cout<<"\n\n#matching prefix string :"<<endl;
	cout<<"......................................."<<endl;
	px.check_prefix();
	return 0;
}