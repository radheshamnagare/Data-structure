/*required header files*/
using namespace std;
#include<iostream>
#include<stdexcept>
#include<string>
/*defination of namespace for globle variable*/
namespace glob_var{
	long inc;
};
/*adding namespace to programm*/
using namespace glob_var ;
/*defination of hash_tbl class for defining & declaring variable also function 
to generate meaningful information*/
class hash_tbl{
  /*declaration of variable*/
   private :
      int n,inx,j;
      string value;
      /*structure for hash table*/
      struct h_tbl{
         long key;
         string value;
      }*arr;

  public :
    /*public constructor of hash_tbl to initilize & clalling initil requred method*/
    hash_tbl(){
     n = 0;
     j = 0;
     inx = 0;
     value.clear();
     init_glob();
     init();
    }
    /*initilize globle namespace variable*/
    void init_glob(){
    	inc = 99;
    }
    /*get user input*/
    void init(){

    	try{
           cout<<"\nEnter the hash table size :";
           cin>>n;
           if(n<=0)
           	throw runtime_error("Error : size should be greather than zero");
           else
           	arr = new h_tbl[n];
    	}
    	catch(runtime_error e){
            cout<<e.what(); 
    	}
    }
    /*hash_key() for insert as well read data from hash_table*/
    int hash_key(long key){
    	if(key%10 > (n-1))
    		return -1;
       return (key%10);
    }
    /*insert (key,value) in hash_table*/
    void _insert(int inx,long key,string value){
        arr[inx].key = key;
        arr[inx].value = value;   
    }
    /*insertion of data*/
    void _insert(){
        try{
          
        	inx = hash_key(++inc);
            if(inx == -1)
            	throw runtime_error("error :index over");
        	
        	if(inx != -1){
        		 cout<<"\nEnter the string value :";
        		 cin>>value;
        		_insert(inx,inc,value);
        	      j++;
           }
        }
        catch(runtime_error e){
        	cout<<e.what();
        }
    }
    /*display all data in hash table*/
    void _display(){
       cout<<"\n\nindex\tkey\tvalue"<<endl;
       cout<<"................................................................."<<endl;
       init_glob();
       int i,key;
       for(i=0,key=++inc;i<n;i++,key++){
       	    inx = hash_key(key);
       	    if(inx !=-1 && i<j)
       	    	cout<<i<<"\t"<<arr[inx].key<<"\t"<<arr[inx].value<<endl;
       }
    }
    /*display perticular record through key*/
    void _display(long key){
       try{	
       inx = hash_key(key);
       if(inx == -1 || arr[inx].value.length() == 0)
        throw runtime_error("error :key not found in table");	
       cout<<"\n\nindex\tkey\tvalue"<<endl;
       cout<<"................................................................."<<endl;
       
       if(inx !=-1)
        cout<<inx<<"\t"<<arr[inx].key<<"\t"<<arr[inx].value<<endl;
       }
       catch(runtime_error e){
       	cout<<e.what()<<endl;
       }
    }

};
/*driver key*/
int main(int argc, char const *argv[])
{
  /*declaration of variable*/
	int cho,key;
	hash_tbl ht;
 // choises
do{

   cout<<"\n\n1-insert\n2-display help of key\n3-display all"<<endl;
   cout<<"Enter th choise :";
   cin>>cho;

    switch(cho){

     case 1:ht._insert();
           break;
     case 2:
            cout<<"\nEnter the key :";
            cin>>key;
            ht._display(key);
            break;
     case 3:ht._display();
            break;
     default : cout<<"wrong choise.";
                   
    }

}while(cho < 4);

	return 0;
}