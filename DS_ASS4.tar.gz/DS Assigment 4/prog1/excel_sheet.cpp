/*required header files*/
using namespace std;
#include<iostream>
#include<stdexcept>
#include<string>
#include<map>

/*defination of _map class for declaration & define required functions also variables*/
class _map{
  /*variable declaration*/ 
  private :
      int i;
      char ch;
      map <char,int> mp;
      map <int,char> l;
  public :
     /*public constructor of map class*/
      _map(){
        i = 0;
        insert();
      }
     /*inserting A-Z character to map class*/ 
      void insert(){
        for(ch = 'A';ch<='Z';ch++)
        {
          i++;
          mp.insert(pair <char,int>(ch,i));
          if(i<25)
          l.insert(pair<int,char>(i,ch));
        }
        l.insert(pair<int,char>(0,'Z'));
      }
      /*mapping the data*/
      int mapping(char key){
        if(mp[key]>0 && mp[key]<=26)
         return mp[key];
         return -1;
      }
      char mapping(int key){
      	if(l[key]>='A' && l[key]<='Z')
          return l[key];
       return '0';
      }
};
/*excel_sheet class for to perform operation which you want*/
class excel_sheet : public _map{
  /*declaration of variable*/
  private :
   int i;
   long col_no;
   long cno,value;
   string col_nm;
  public :
  /*public constructor of class*/
    excel_sheet(){
      col_nm = "";
      col_no = 0;
      cno = 0;
      value = 0;
    }
    /*initilize instance member of class*/
    void init(){
      col_no = 1;
      value = 0;
    }
    /*get input form user*/
    void input(){
      init();
      cout<<"\nEnter the column name :";
      cin>>col_nm;
      cout<<"Enter the coumn no :";
      cin>>cno;
    }
     /*validate exel column_name & no*/
    long validate_col(){
        if(col_nm.length() == 1){
          return mapping(col_nm[0]);
        }
        else{
            for(i=0;i<(col_nm.length()-1);i++){
               value = mapping(col_nm[i]);
               if(value != -1)
               col_no*=(26*value);
            }
            if(col_nm.length()>2)
            col_no+=26;

            value = mapping(col_nm[i]);
            if(value != -1)
            col_no+=value;
            
        }
        return col_no;
    }
    /*actual matching user enterd col_no & calculate col_no*/
    bool matching(){
       if(col_no == cno)
        return true;

      return false;
    }
    /*display user enter col_name & col_no*/
    void _display(){
      cout<<"{"<<col_nm<<","<<cno<<"}";
    }

    void extract_col(int col_no){
    	try{
            
            if(col_no <= 0)
            	throw runtime_error("error:invalid column number");
            col_nm.clear();

            while(col_no > 0){
            	
            	int rm = col_no % 26;
            	col_no/=26;
            	char ch = mapping(rm);
            	if(rm != '0')
            	col_nm.insert(0,1,ch);
                
            }
          cout<<"\nEtracted col name :"<<col_nm<<endl; 
    	}
    	catch(runtime_error e){
    		cout<<e.what()<<endl;
    	}
    }
};
/*driver code*/
int main(int argc, char const *argv[]) {
  /*declaration of variable*/
  int n,cno,ch;
  excel_sheet exl;
  
  do{

      cout<<"\n\n1-extract column no\n2-validate col_name & col_no";
      cout<<"\nEnter the choise :";
      cin>>ch;

       switch(ch){

       	case 2:/*get limit from usre*/
              cout<<"\nEnter the limit :";
              cin>>n;
              /*calling sequce wise method of class to matching user data*/
              while(n-- >0){
               exl.input();
               exl.validate_col();
               exl._display();
               if(exl.matching())
               cout<<" is match"<<endl;
               else
               cout<<" is not match"<<endl;
              }
              break;

        case 1:cout<<"\nEnter col no :";
               cin>>cno;
               exl.extract_col(cno);
               break;   
       }

  }while(ch<3);
  
  return 0;
}
