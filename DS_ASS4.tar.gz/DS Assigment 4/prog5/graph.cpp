/*preprocessing header*/
using namespace std;
#include<iostream>
#include<stdexcept> 
#include<string>
#include<map>
#include<vector>
#include <list> 
 /*_map class for mapping the vertex*/
class _map{
  /*declaration of variable*/
  private :
      int i;
      char ch;
      map <int,char> mp;
  public :
    /*public constructor of class for initilize instance member*/
      _map(){
        i = 0;
        insert();
      }
      /*inser data in map*/
      void insert(){
        for(ch = 'A';ch<='Z';ch++)
        {   
          mp.insert(pair <int,char>(i++,ch));
        }
      }
      /*mapping the data*/
      char mapping(int key){
        if(mp[key]>='A' && mp[key]<='Z')
         return mp[key];
       return '0';
      }
      
}; 
  /*graph class for performing operation*/ 
class Graph : public _map
{ 
 /*declaration of variable*/
 private :   
    int v; 
    list<int> *adj; 
    vector <string> pth;
    string p;
public: 
 /*constructor of graph class for initilize instance member*/ 
Graph() 
{   init(); 
    p.clear();
} 
/*get user input*/
void init(){
    cout<<"\nEnter the no of vertices :";
    cin>>v;
    adj = new list<int>[v];
}  
/*adding edge between two vertices*/
void add_edge(int u, int v) 
{ 
    adj[u].push_back(v); 
} 
/*print all posible paths from two vertices*/  
void print_paths(int s, int d) 
{  
    bool *visited = new bool[v];  
    int *path = new int[v]; 
    int indx = 0; 
  
    for (int i = 0; i < v; i++) 
        visited[i] = false; 
  
    all_paths(s, d, visited, path,indx); 
} 
/*print large path between two vertices*/
void large_path(){
   int max=0,p=0; 
   try{
    if(pth.size()<=0)
      throw runtime_error("");
   for(int i=0;i<pth.size();i++){
      if(pth[i].length() > max)
      {
         max = pth[i].length();
         p = i;
      }
   }
     cout<<"\n large path :"<<pth[p]<<" with length "<<--max<<endl;
  }
  catch(runtime_error e){
    cout<<"\n\terror :there is no path-NULL"<<endl;
  }

 
}  
/*priting path between two vertices*/
void all_paths(int u, int d, bool visited[], int path[], int &inx) 
{ 
    
    visited[u] = true; 
    path[inx] = u; 
    inx++; 
  
    if (u == d) 
    { 
        for (int i = 0; i<inx; i++) {
            if(mapping(path[i]!='0')){
            cout << mapping(path[i]) << " "; 
            p.push_back(mapping(path[i]));
           }
        }
        pth.push_back(p);
        p.clear();
        cout << endl; 
          
    } 
    else  
    { 
         
        list<int>::iterator i; 
        for (i = adj[u].begin(); i != adj[u].end(); ++i) 
            if (!visited[*i]) 
                all_paths(*i, d, visited, path, inx); 
    } 
  
     
    inx--; 
    visited[u] = false; 
 } 
  
};  
/*diver code*/
int main() 
{ 
    //variabble 
    Graph g; 
    int s , d ,cho;
    int v1,v2,n;
    //choises
    do{
       cout<<"\n1-insert edge\n2-print_all_path\n3-print_large_path";
       cout<<"\nEnter the choise :";
       cin>>cho;

       switch(cho){
        case 1: cout<<"\nEnter the no of edge:";
                cin>>n;
                cout<<"\nEnter the edge with pair :";
                for(int i=0;i<n;i++){
                cin>>v1>>v2;
                g.add_edge(v1,v2);
                }
                break;
        case 2:cout<<"\nEnter the source & destination vertex :";
               cin>>s>>d;
               cout << "Following are all different paths from "<< s <<" to " << d << endl; 
               g.print_paths(s, d);
               break;
        case 3:g.large_path();
               break;
        default: cout<<"\nExit"<<endl;
                break;              

       }
    }while(cho<4);

    return 0; 
} 