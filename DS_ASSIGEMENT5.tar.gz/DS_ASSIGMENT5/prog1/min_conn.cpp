using namespace std;
#include<iostream>
#include<vector>
#include<stdexcept>

class adj{
  
  private :
    int v;
    int sum;
    int e;
    int s,d,w;
    int **arr;
  public :

    adj(){
      v = 0;
      e = 0;
      sum = 0;
      init();
    }

    void init(){
      cout<<"\nEnter the no of vertex:";
      cin>>v;
      cout<<"\nEnter the no of edge :";
      cin>>e;
      arr = new int*[v];
       for(int i=0;i<v;i++){
         arr[i] = new int[v];
         for(int j=0;j<v;j++)
          arr[i][j] = -1;  
       }
    }

    void insert_edge(){

       try{
          
          for(int i=0;i<e;i++){
          cout<<"\nEnter source & destination :";
          cin>>s>>d;
             if(s>=v || d>=v || s==-1 || d==-1)
              throw runtime_error("Error : invalid vertex enterd");
          cout<<"\nEnter weigth :";
          cin>>w; 
              if(w<0)
               throw runtime_error("Error : invalid weigth enterd"); 
            arr[s][d] = w;
          }     
       }
       catch(runtime_error e){
         cout<<"\n\t"<<e.what()<<endl;
       }
    }
    
    int min_zero(int j){

      for(int i=0;i<v;i++)
      {
        if(arr[j][i]>=0)
          return arr[j][i];
      }

      return -1;
    }
    int _min(int j){
      int m = min_zero(j);
      int p = -1;
      for(int i=0;i<v;i++){
        if(arr[j][i]>=0 && arr[j][i]<=m){
          m = arr[j][i];
          p = i;
          
        }
       } 
       sum+=m;
       
       return p; 
    }
    int _min(){

    }
    void find_min_each(){
       int j = 0,f=0;
       disp_mat();
       for(int i=0;i<v;i++)
       { 
          j = _min(j);
           
           if(j == -1)
           break;
           if(j == v-1){
            f = 1;
            break;
           }
           
       }
      
       if(f == 1)
        cout<<"\nGraph is minimal connected with weigth "<<sum<<endl;
       else
        cout<<"\ngraph is not minimal connected graph"<<endl;
    }

    void disp_mat(){
      cout<<"\nAdjecency matrix :"<<endl;
       for(int i=0;i<v;i++)
       {
         for(int j=0;j<v;j++)
          cout<<arr[i][j]<<"\t";
         cout<<endl;
       }
    }

};

int main(int argc, char const *argv[])
{
  adj mg;
  mg.insert_edge();
  mg.find_min_each();

return 0;
}