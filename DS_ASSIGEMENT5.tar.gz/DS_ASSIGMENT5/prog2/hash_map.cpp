using namespace std;
#include<iostream>
#include<stdexcept>

class _HashMap{

public:
string value ;

struct _map
{
 
 string id; 
 struct _mapList{
    string value;  
    _mapList *next;
  }*mpl;
 
 struct _map *next;

}*_m;
  
public :

_HashMap(){
 init(&_m);
}
  
void init(struct _map **head){
 *head = NULL;
}

 struct _map * newNode(string id){
 	struct _map *newnode;
 	newnode = new _map;
 	newnode->id = id;
 	newnode->next = NULL;
 	newnode->mpl = NULL;
 return newnode;
 }
 
 struct _map::_mapList * newNd(string value){
      struct _map::_mapList *newnode;
      newnode = new _map::_mapList;
      newnode->value = value;
      newnode->next = NULL;
   return newnode;   
 }
 void _insert(struct _map::_mapList **m,string value){
     _map::_mapList *t;
     if(*m == NULL)
     	*m = newNd(value);
     else{
        for(t=*m;t->next!=NULL;t=t->next);
        t->next = newNd(value);  
     }
 }

 void _insert(struct _map **m,string id){
  struct _map *t;

 	if(*m == NULL){
       *m = newNode(id); 
    }
    else{
       for(t=*m;t->next!=NULL;t=t->next);
       t->next = newNode(id);       
    }
 }

 struct _map * _get(string id){
  struct _map *t;
   for(t=_m;t!=NULL;t=t->next)
   {
   	  if(t->id == id)
   	  	return t;
   	  
   }

   return NULL;
 }

int _search(string id){
    struct _map *t;
    for(t=_m;t!=NULL;t=t->next)
    {
    	if(t->id == id)
    		return 1;
    }
  return 0;  
}
 void _sort(){
    string t;
    struct _map *t1;
    struct _map::_mapList *t2,*t3;

    for(t1=_m;t1!=NULL;t1=t1->next){
      for(t2=t1->mpl;t2!=NULL;t2=t2->next){
      	  for(t3=t1->mpl;t3!=NULL;t3=t3->next){
      	  	  if(t2->value < t3->value)
      	  	  {
      	  	  	t = t2->value;
      	  	  	t2->value = t3->value;
      	  	  	t3->value = t;
      	  	  }
      	  }
      }  
    }

    _display();
 }

 void _display(){
    struct _map *t1;
    struct _map::_mapList *t2;
    cout<<"\nid\tvalue"<<endl;
    cout<<".................................................................."<<endl;
    for(t1=_m;t1!=NULL;t1=t1->next)
    {
    	cout<<"\n"<<t1->id;
    	for(t2=t1->mpl;t2!=NULL;t2=t2->next){
           cout<<"\t"<<t2->value<<" ";
    	}
    }
 }
 void _display(struct _map::_mapList *mpl){
 	struct _map::_mapList *t;
 	for(t=mpl;t!=NULL;t=t->next)
 		cout<<t->value<<" ";
 }

};

int main(int argc, char const *argv[])
{
	int ch;
	string id,value;
	_HashMap hm;


    do{

       cout<<"\n1-create key\n2-insert value in key\n3-display hash map\n4-display key wise value\n5-sort";
       cout<<"\nEnter the choise:";
       cin>>ch;

       switch(ch){
          
          case 1:
                 try{
                     cout<<"\nEnter the id :";
                     cin>>id;
                     if(hm._search(id) == 1)
                     	throw runtime_error("Error : duplicate id insertion in _HashMap");
                     hm._insert(&hm._m,id);
                 }
                 catch(runtime_error e){
                 	cout<<"\n\t"<<e.what()<<endl;
                 }
          
                 break;
          case 2:    
                 try{
                    cout<<"\nEnter the id :";
                    cin>>id;
                    _HashMap::_map *v;
                    v = hm._get(id);
                    if(v == NULL)
                     throw runtime_error("Error : id not found in _HashMap");
                    cout<<"\nEnter the value :";
                    cin>>value;
                    hm._insert(&v->mpl,value);      
                 }
                 catch(runtime_error e){
                 	cout<<"\n\t"<<e.what()<<endl;
                 }
                 break;
       
         case 3: 
                 hm._display();
                 cout<<endl; 
                 break;
         case 4: 
                 try{
                   cout<<"\nEnter the id :";
                   cin>>id;
                   _HashMap::_map *v;
                   v = hm._get(id);
                   if(v == NULL)
                      throw runtime_error("Error : id not found in _HashMap");
                   cout<<"\nid\tvalue"<<endl;;
                   cout<<".................................................................."<<endl;
                   cout<<id<<"\t";
                   hm._display(v->mpl);
                 }
                 catch(runtime_error e){
                 	cout<<"\n\t"<<e.what()<<endl;
                 }
                 cout<<endl;
                 break;  
        case 5: hm._sort();
                break;
        default:cout<<"wrong choise...";
                break;                                   
       }

    }while(ch<6);

 return 0;
}