/*required header file declaration */
#include<stdio.h>
#include<stdlib.h>


/*declaration of macro for memory allowcation purpose*/
#define memory (struct node *)malloc(sizeof(struct node))
/*declaration of structure of node*/
struct node{
  int d;
  struct node *next;
  struct node *left,*right;
}*top;
/*initilization root of tree to NULL*/
void init(struct node **root){
	*root = NULL;
}
/*newNode() return structure of node pointer*/
struct node * newNode(int d){
	struct node *newnode;
	newnode = memory;
	newnode->left = NULL;
	newnode->right = NULL;
  newnode->next = NULL;
	newnode->d = d;
return newnode;	
}
/*push() push element in structure of node as stack*/
void push(struct node *N){
  struct node *t;
  if(top == NULL)
    top = N;
  else
  {
    for(t=top;t->next!=NULL;t=t->next);
     t->next = N;
  }
}
/*pop() element form structure of node as stack*/
struct node * pop()
{
  struct node *t;
  if(top == NULL)
    return NULL;
  else
  {
    t = top;
    top = top->next;
    t->next = NULL;
  }

  return t;
}
/*insert_node() creating BT and return root of tree*/
struct node * insert_node(struct node *N,int d){
struct node *t,*nd;
   
      if(N == NULL){
        N = newNode(d);
        push(N); 
      }
      else
      {
          if(top!=NULL){
            
            if(top->left!=NULL && top->right!=NULL)
              pop();

            if(top->left == NULL){
               nd = newNode(d);
               top->left = nd;
               push(nd);
            }
            else if(top->right == NULL){
               nd = newNode(d);
               top->right = nd;
               push(nd);
            }

          }
      }

 return N;
}
/*postorder() postorder traversal of tree*/
void postorder(struct node *N){
  if(N == NULL)
    return;
  postorder(N->left);
  postorder(N->right);
  printf("%d ",N->d);
}

struct node * find_ancestor(struct node *N,int n1,int n2){
   
    if(N == NULL)
      return NULL;
    if(N->d == n1 || N->d == n2)
      return N;

    struct node *la = find_ancestor(N->left,n1,n2);
    struct node *ra = find_ancestor(N->right,n1,n2);

    if(la && ra)
      return N;

    if(la!=NULL)
      return la;
    else
      return ra; 
}
/*start main execution of programm*/
int main(){

  /*require declaration of variable*/
  int cho,d,k,i;
  int n1,n2;
  struct node *root,*ance;
  system("clear");
  
  init(&root);//initilization root of tree
  // choises
  do{

       printf("\n\t1-insert in BT \n\t2-postorder of tree\n\t3-lowest common ancestor\n\t4-exit\n:");
       scanf("%d",&cho);

       switch(cho){
           case 1: printf("\nEnter the node :");
                   scanf("%d",&d);
                   root = insert_node(root,d);
                   break;

           case 2: postorder(root);
                   break;

           case 3: printf("\nEnter the two node :");
                   scanf("%d%d",&n1,&n2);
                   ance = find_ancestor(root,n1,n2);
                   if(ance!=NULL)
                    printf("\nAncestor of (%d,%d) is %d",n1,n2,ance->d);
                  break;
           default:printf("\nexited ...");
                  break;

       }

  }while(cho<4);

  return 0;
}
//end